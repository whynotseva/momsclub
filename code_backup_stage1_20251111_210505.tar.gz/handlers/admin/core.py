from aiogram import Router, F, types
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery, FSInputFile
from aiogram.fsm.context import FSMContext
import os
import logging
from utils.constants import ADMIN_IDS
from database.config import AsyncSessionLocal
from database.crud import (
    get_total_users_count,
    get_active_subscriptions_count,
    get_expired_subscriptions_count,
    get_total_payments_amount,
    get_total_promo_code_uses_count,
)
from datetime import datetime

logger = logging.getLogger(__name__)

core_router = Router()


def register_admin_core_handlers(dp):
    dp.include_router(core_router)


@core_router.message(Command("admin"), F.chat.type == "private")
async def cmd_admin_check(message: types.Message):
    user_id = message.from_user.id
    logger.info(f"[core] Команда /admin от ID: {user_id}")

    if user_id not in ADMIN_IDS:
        await message.answer("У вас нет прав доступа к этой команде.")
        return

    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📊 Статистика", callback_data="admin_stats")],
            [InlineKeyboardButton(text="👤 Поиск пользователя", callback_data="admin_find_user")],
            [InlineKeyboardButton(text="🤝 Реферальные связи", callback_data="admin_referral_info")],
            [InlineKeyboardButton(text="🎟️ Управление промокодами", callback_data="admin_manage_promocodes")],
            [InlineKeyboardButton(text="📅 Сроки подписок", callback_data="admin_subscription_dates")],
            [InlineKeyboardButton(text="🎂 Дни рождения пользователей", callback_data="admin_birthdays:0")],
            [InlineKeyboardButton(text="🚫 Заявки на отмену автопродления", callback_data="admin_cancellation_requests")],
            [InlineKeyboardButton(text="✖️ Закрыть", callback_data="admin_close")],
        ]
    )

    banner_path = os.path.join(os.getcwd(), "media", "админка.jpg")
    banner_photo = FSInputFile(banner_path)
    await message.answer_photo(photo=banner_photo, caption="Панель администратора Mom's Club:", reply_markup=keyboard)


@core_router.callback_query(F.data == "admin_stats")
async def process_admin_stats(callback: CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("У вас нет доступа к этой функции", show_alert=True)
        return

    try:
        await callback.answer("Загрузка статистики...", show_alert=False)
        async with AsyncSessionLocal() as session:
            total_users = await get_total_users_count(session)
            active_subs = await get_active_subscriptions_count(session)
            expired_subs = await get_expired_subscriptions_count(session)
            total_payments = await get_total_payments_amount(session)
            total_promo_uses = await get_total_promo_code_uses_count(session)

        conversion_rate = round((active_subs / total_users * 100), 1) if total_users > 0 else 0
        avg_payment = round(total_payments / (active_subs + expired_subs), 1) if (active_subs + expired_subs) > 0 else 0
        current_time = datetime.now().strftime('%d.%m.%Y %H:%M')
        stats_text = f"""
<b>📊 Статистика Mom's Club:</b>

👥 <b>Всего пользователей:</b> {total_users}
✅ <b>Активных подписок:</b> {active_subs}
❌ <b>Истекших подписок:</b> {expired_subs}
🎁 <b>Использовано промокодов:</b> {total_promo_uses} раз(а)
💰 <b>Общая сумма платежей:</b> {total_payments} ₽

📈 <b>Конверсия (активные/всего):</b> {conversion_rate}%
💵 <b>Средний платеж:</b> {avg_payment} ₽

<i>Данные актуальны на: {current_time}</i>
"""

        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text="📊 Обновить данные", callback_data="admin_stats")],
                [InlineKeyboardButton(text="« Назад", callback_data="admin_back")],
            ]
        )
        try:
            await callback.message.delete()
        except Exception:
            pass
        await callback.message.answer(stats_text, reply_markup=keyboard, parse_mode="HTML")
    except Exception as e:
        logger.error(f"[core] Ошибка статистики: {e}")
        keyboard = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="« Назад", callback_data="admin_back")]])
        await callback.message.answer(f"❌ Ошибка при получении статистики: {str(e)}", reply_markup=keyboard)


def _admin_menu_keyboard():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📊 Статистика", callback_data="admin_stats")],
            [InlineKeyboardButton(text="👤 Поиск пользователя", callback_data="admin_find_user")],
            [InlineKeyboardButton(text="🤝 Реферальные связи", callback_data="admin_referral_info")],
            [InlineKeyboardButton(text="🎟️ Управление промокодами", callback_data="admin_manage_promocodes")],
            [InlineKeyboardButton(text="📅 Сроки подписок", callback_data="admin_subscription_dates")],
            [InlineKeyboardButton(text="🎂 Дни рождения пользователей", callback_data="admin_birthdays:0")],
            [InlineKeyboardButton(text="🚫 Заявки на отмену автопродления", callback_data="admin_cancellation_requests")],
            [InlineKeyboardButton(text="✖️ Закрыть", callback_data="admin_close")],
        ]
    )


@core_router.callback_query(F.data == "admin_cancel")
async def process_cancel(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("У вас нет доступа к этой функции", show_alert=True)
        return
    await state.clear()
    keyboard = _admin_menu_keyboard()
    banner_path = os.path.join(os.getcwd(), "media", "админка.jpg")
    try:
        await callback.message.delete()
    except Exception:
        pass
    banner_photo = FSInputFile(banner_path)
    await callback.message.answer_photo(photo=banner_photo, caption="Операция отменена.\nПанель администратора Mom's Club:", reply_markup=keyboard)
    await callback.answer()


@core_router.callback_query(F.data == "admin_back")
async def process_back(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("У вас нет доступа к этой функции", show_alert=True)
        return
    try:
        await state.clear()
    except Exception:
        pass
    await callback.answer()
    keyboard = _admin_menu_keyboard()
    banner_path = os.path.join(os.getcwd(), "media", "админка.jpg")
    banner_photo = FSInputFile(banner_path)
    try:
        await callback.message.delete()
    except Exception:
        pass
    await callback.message.answer_photo(photo=banner_photo, caption="Панель администратора Mom's Club:", reply_markup=keyboard)


@core_router.callback_query(F.data == "admin_close")
async def process_close(callback: CallbackQuery, state: FSMContext):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("У вас нет доступа к этой функции", show_alert=True)
        return
    await state.clear()
    try:
        await callback.message.delete()
    except Exception:
        pass
    await callback.answer()


@core_router.callback_query(F.data == "ignore")
async def process_ignore(callback: CallbackQuery):
    """Пустой обработчик для информационных кнопок (снимает индикатор)."""
    await callback.answer()